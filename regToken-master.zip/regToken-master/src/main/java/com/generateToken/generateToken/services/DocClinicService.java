package com.generateToken.generateToken.services;

public interface DocClinicService {
  String deleteRel(Long clinicId);
}
