package com.generateToken.generateToken.Custome;

public class ClinicNotFoundException extends Exception{
  public ClinicNotFoundException(String message) {
    super(message);
  }
}
