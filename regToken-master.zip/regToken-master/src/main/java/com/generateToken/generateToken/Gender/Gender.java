package com.generateToken.generateToken.Gender;

public enum Gender {
    MALE,
    FEMALE
}
