package com.generateToken.generateToken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateTokenApplicationTests {

	@Test
	void contextLoads() {
	}

}
